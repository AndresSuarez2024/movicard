package com.example.stripe_backnend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StripeBacknendApplicationTests {

	@Test
	void contextLoads() {
	}

}
