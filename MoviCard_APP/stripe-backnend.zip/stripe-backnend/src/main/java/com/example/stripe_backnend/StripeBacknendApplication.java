package com.example.stripe_backnend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StripeBacknendApplication {

	public static void main(String[] args) {
		SpringApplication.run(StripeBacknendApplication.class, args);
	}

}