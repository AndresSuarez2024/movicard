package com.example.movicard.model

data class ReceiptResponse (
    val receiptUrl : String
)