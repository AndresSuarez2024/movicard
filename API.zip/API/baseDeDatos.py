import mysql.connector

def connect_to_db():
    try:
        connection = mysql.connector.connect(
            host="10.0.82.2",
            user="christopher",
            password="christopher",
            database="movicard",
            charset='utf8mb4',
            collation='utf8mb4_general_ci'
        )
        return connection
    except mysql.connector.Error as err:
        raise Exception(f"Error de conexión: {err}")

def get_cursor(connection):
    return connection.cursor()